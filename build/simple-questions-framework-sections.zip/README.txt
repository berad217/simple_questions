# High-Uncertainty Cognitive Style: Section Files

These are the individual section files for the communication framework.

**Built**: 2026-07-20 18:47:03

Read them in order (section-01 through section-12) or jump to specific topics.

For the compiled single-document version, see the PDF or HTML files.
